function X = rad(X);

X.basis = rad(X.basis);
